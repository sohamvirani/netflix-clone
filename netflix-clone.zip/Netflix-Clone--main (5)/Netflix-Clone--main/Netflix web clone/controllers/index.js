module.exports.userController = require("./user.controller");
module.exports.MovieController = require("./Movie.controller");

