module.exports.userSchema = require("./user.model");
module.exports.MovieSchema = require("./Movie.model");
