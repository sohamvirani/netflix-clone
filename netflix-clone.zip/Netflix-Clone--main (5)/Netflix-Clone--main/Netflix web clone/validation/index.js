module.exports.userValidation = require("./user.validation");
module.exports.MovieValidation = require("./Movie.validation");